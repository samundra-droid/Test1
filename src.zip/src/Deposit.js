// DepositButton.js
import React from 'react';

function DepositButton({ onClick }) {
  return (
    <button className="btn btn-success" onClick={onClick}>
      Deposit
    </button>
  );
}
function DepositForm({ onCancel, onDeposit }) {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    if (accountNumber && amount) {
      onDeposit(Number(amount));
    }
  };

  return (
    <form className="deposit-form" onSubmit={handleSubmit}>
      <div className="form-group">
        <label htmlFor="accountNumber">Account Number</label>
        <input
          type="text"
          id="accountNumber"
          className="form-control"
          value={accountNumber}
          onChange={(e) => setAccountNumber(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <label htmlFor="amount">Amount</label>
        <input
          type="number"
          id="amount"
          className="form-control"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
      </div>
      <div className="form-group">
        <button type="button" className="btn btn-danger" onClick={onCancel}>
          Cancel
        </button>
        <button type="submit" className="btn btn-primary">
          Deposit
        </button>
      </div>
    </form>
  );
}

export default DepositForm;


