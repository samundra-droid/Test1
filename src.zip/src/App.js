import React from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import locationIcon from './location.jpg';
import contactIcon from './contact.jpg';
import bankYourWayIcon from './bankyourway.jpg';
import bankLogo from './bank.jpg';
import largeImage from './largeimage.jpg';
import branchLocationImage from './branch.jpg';
import boxImage1 from './image1.jpg';
import boxImage2 from './image2.jpg';
import boxImage3 from './image3.jpg';
import boxImage4 from './image4.jpg';
import boxImage5 from './image5.jpg';
import boxImage6 from './image6.jpg';
import bottomImage from './footer.jpg';
import questionIcon from './question.jpg';
import phoneIcon from './call.jpg';
import adviceIcon from './advice.jpg';
import facebookIcon from './fb.jpg';
import twitterIcon from './x.jpg';
import youtubeIcon from './utube.jpg';
import linkedinIcon from './linkedin.jpg';
import instagramIcon from './insta.jpg';

// Import components
import SignIn from './Signin';
import Dashboard from './Dashboard';
import Transaction from './transaction';

function App() {
  const [activeTab, setActiveTab] = React.useState('Featured');

  const handleTabClick = (tabName) => {
    setActiveTab(tabName);
  };

  return (
    <Router>
      <div className="App">
        {/* Main Navigation */}
        <nav className="main-nav">
          <div className="container d-flex justify-content-start">
            <Link to="/" className="main-link">Personal</Link>
            <Link to="/" className="main-link">Small Business</Link>
            <Link to="/" className="main-link">Commercial</Link>
            <Link to="/" className="main-link">About Us</Link>
            <Link to="/" className="main-link">Investors</Link>
          </div>
        </nav>

        {/* Top Header with ScotiaBank, Search Box, and Action Links */}
        <nav className="navbar navbar-light bg-light">
          <div className="container d-flex justify-content-between align-items-center header-row">
            <div className="scotiabank-container d-flex align-items-center">
              <Link to="/" className="scotiabank-logo">
                <img src={bankLogo} alt="bank" className="icon" /> Scotiabank
              </Link>
              <div className="search-box">
                <input type="text" placeholder="Search" />
              </div>
            </div>

            {/* Action Links */}
            <div className="action-links d-flex">
              <div className="action-item">
                <img src={locationIcon} alt="Location" className="icon" />
                <Link to="/" className="action-link">Location</Link>
              </div>
              <div className="action-item">
                <img src={contactIcon} alt="Contact Us" className="icon" />
                <Link to="/" className="action-link">Contact Us</Link>
              </div>
              <div className="action-item">
                <img src={bankYourWayIcon} alt="Bank Your Way" className="icon" />
                <Link to="/" className="action-link">Bank Your Way</Link>
              </div>

              {/* Sign In Button */}
              <div className="sign-in-container">
                <Link to="/signin" className="sign-in-button">Sign In</Link>
                <p className="activate-now-text">
                  New to Scotia Online? <span className="activate-now">Activate now</span>
                </p>
              </div>
            </div>
          </div>
        </nav>

        {/* Additional icons under main navigation */}
        <nav className="sub-nav">
          <div className="container d-flex justify-content-center">
            <Link to="/" className="main-link">Advice+</Link>
            <Link to="/" className="main-link">Scene+</Link>
            <Link to="/" className="main-link">Bank Accounts</Link>
            <Link to="/" className="main-link">Credit Cards</Link>
            <Link to="/" className="main-link">Loans & Lines of Credit</Link>
            <Link to="/" className="main-link">Insurance</Link>
            <Link to="/" className="main-link">Fees</Link>
          </div>
        </nav>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<SignIn />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/transaction" element={<Transaction />} />
        </Routes>

        {/* Large Image with Button */}
        <div className="large-image-container">
          <img src={largeImage} alt="Large Banner" className="large-image" />
          <button className="view-packages-button">View our packages</button>
        </div>

        {/* Tab Buttons */}
        <div className="tabs-container">
          {['Featured', 'Accounts', 'Credit Cards', 'Borrowing', 'Investments', 'Learning'].map((tab) => (
            <button
              key={tab}
              className={`tab-button ${activeTab === tab ? 'active' : ''}`}
              onClick={() => handleTabClick(tab)}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Featured Text Section */}
        {activeTab === 'Featured' && (
          <div className="featured-section">
            <h2 className="featured-title">Featured</h2>
            <p className="featured-subtext">Helping plan for your financial future</p>

            {/* Three Vertical Boxes in Two Rows */}
            <div className="boxes-container">
              <div className="box">
                <img src={boxImage1} alt="Box 1" />
              </div>
              <div className="box">
                <img src={boxImage2} alt="Box 2" />
              </div>
              <div className="box">
                <img src={boxImage3} alt="Box 3" />
              </div>
            </div>
            <div className="boxes-container">
              <div className="box">
                <img src={boxImage4} alt="Box 4" />
              </div>
              <div className="box">
                <img src={boxImage5} alt="Box 5" />
              </div>
              <div className="box">
                <img src={boxImage6} alt="Box 6" />
              </div>
            </div>
          </div>
        )}

        {/* Branch Location Section */}
        <div className="branch-location-container">
          <img src={branchLocationImage} alt="Branch Location" className="branch-location-image" />
          <button className="find-branch-button">Find your nearest branch</button>
        </div>

        {/* Footer with Disclaimer and Buttons */}
        <div className="footer-container">
          <img src={bottomImage} alt="Bottom Image" className="footer-image" />
          <p className="footer-text">Scotiabank is a trade name used by the Bank of Nova Scotia, a CIDC member.</p>

          <div className="buttons-container">
            {/* Have a question? Button */}
            <div className="button">
              <img src={questionIcon} alt="Question Icon" className="button-icon" />
              <div className="button-text">Have a question?</div>
              <div className="button-subtext">we have an answer</div>
              <Link to="/help" className="button-link">Help Centre</Link>
            </div>

            {/* Call Scotiabank Button */}
            <div className="button">
              <img src={phoneIcon} alt="Phone Icon" className="button-icon" />
              <div className="button-text">Call Scotiabank</div>
              <div className="button-subtext">1.800.4SCOTIA</div>
              <Link to="/phone" className="button-link">More phone numbers</Link>
            </div>

            {/* Get Advice Button */}
            <div className="button">
              <img src={adviceIcon} alt="Advice Icon" className="button-icon" />
              <div className="button-text">Get advice</div>
              <div className="button-subtext">Meet with an advisor</div>
              <Link to="/appointment" className="button-link">Book an appointment</Link>
            </div>
          </div>

          {/* Social Media Icons */}
          <div className="social-icons">
            <a href="https://facebook.com" className="social-icon"><img src={facebookIcon} alt="Facebook" /></a>
            <a href="https://twitter.com" className="social-icon"><img src={twitterIcon} alt="Twitter" /></a>
            <a href="https://youtube.com" className="social-icon"><img src={youtubeIcon} alt="YouTube" /></a>
            <a href="https://linkedin.com" className="social-icon"><img src={linkedinIcon} alt="LinkedIn" /></a>
            <a href="https://instagram.com" className="social-icon"><img src={instagramIcon} alt="Instagram" /></a>
          </div>

          {/* Additional Footer Links */}
          <div className="footer-links">
            <Link to="/careers" className="footer-link">Careers</Link>
            <Link to="/security" className="footer-link">Security & Fraud</Link>
            <Link to="/legal" className="footer-link">Legal</Link>
            <Link to="/privacy" className="footer-link">Privacy</Link>
            <Link to="/accessibility" className="footer-link">Accessibility</Link>
            <Link to="/cookie-settings" className="footer-link">Cookie Settings</Link>
          </div>

          {/* Copyright Text */}
          <div className="copyright-text">
            © Scotiabank.com All Rights Reserved
          </div>
        </div>
      </div>
    </Router>
  );
}

export default App;
