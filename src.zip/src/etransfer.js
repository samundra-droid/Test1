import React, { useState } from 'react';

const ETransfer = ({ transactionHistory, setTransactionHistory, balance, setBalance }) => {
  const [fromAccount, setFromAccount] = useState('');
  const [toAccount, setToAccount] = useState('');
  const [amount, setAmount] = useState('');

  const handleTransfer = () => {
    const newBalance = balance - parseFloat(amount);
    const newTransaction = {
      accountNumber: fromAccount,
      type: 'Transfer',
      amount,
      balance: newBalance,
    };

    setTransactionHistory([...transactionHistory, newTransaction]);
    setBalance(newBalance);
    setFromAccount('');
    setToAccount('');
    setAmount('');
  };

  return (
    <div className="transaction-and-transfer">
      <div className="e-transfer-form">
        <h2>E-Transfer</h2>
        <input
          type="text"
          placeholder="From Account Number"
          value={fromAccount}
          onChange={(e) => setFromAccount(e.target.value)}
        />
        <input
          type="text"
          placeholder="To Account Number"
          value={toAccount}
          onChange={(e) => setToAccount(e.target.value)}
        />
        <input
          type="number"
          placeholder="Amount"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
        />
        <button onClick={handleTransfer}>Transfer</button>
        <button onClick={() => { setFromAccount(''); setToAccount(''); setAmount(''); }}>Cancel</button>
      </div>
    </div>
  );
};

export default ETransfer;
