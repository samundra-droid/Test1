import React, { useState } from 'react';
import './transaction.css'; // Create this CSS file for styling

const Transaction = () => {
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [transactionType, setTransactionType] = useState('Deposit');
  const [transactions, setTransactions] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    const date = new Date().toLocaleDateString();
    const newTransaction = {
      date,
      accountNumber,
      type: transactionType,
      amount,
      balance: 1000 + (transactionType === 'Deposit' ? parseFloat(amount) : -parseFloat(amount)) // Example balance calculation
    };
    setTransactions([...transactions, newTransaction]);
    setAccountNumber('');
    setAmount('');
  };

  return (
    <div className="transaction-container">
      <h2>Transaction</h2>
      <form onSubmit={handleSubmit}>
        <label>
          Account Number:
          <input
            type="text"
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            required
          />
        </label>
        <label>
          Amount:
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </label>
        <label>
          Transaction Type:
          <select
            value={transactionType}
            onChange={(e) => setTransactionType(e.target.value)}
          >
            <option value="Deposit">Deposit</option>
            <option value="Withdrawal">Withdrawal</option>
            <option value="E-Transfer">E-Transfer</option>
          </select>
        </label>
        <button type="submit">Submit</button>
      </form>

      <div className="transaction-history">
        <h3>Transaction History</h3>
        <table>
          <thead>
            <tr>
              <th>Date</th>
              <th>Account Number</th>
              <th>Type</th>
              <th>Amount</th>
              <th>Balance</th>
            </tr>
          </thead>
          <tbody>
            {transactions.map((transaction, index) => (
              <tr key={index}>
                <td>{transaction.date}</td>
                <td>{transaction.accountNumber}</td>
                <td>{transaction.type}</td>
                <td>${transaction.amount}</td>
                <td>${transaction.balance}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default Transaction;
